# -*- coding: utf-8 -*-
"""
Created on Mon Feb  6 20:00:08 2023

@author: IDEAS
"""

import arrayAlgorithm
import LinkedList_Algorithm
import BtreeAlgorithems
import random

def read(): 
  numberOfRandomNumbers = int(input("\nHow many numbers should the random file hold?:"))
  with open("test.txt", "w") as w:
     for n in range(0, numberOfRandomNumbers):
         w.write(str(random.randint(0, 10000)))
         w.write(",")
     w.write(str(random.randint(0, 10000)))

  with open("test.txt", "r") as f:
      myArray = f.read().split(",")

  for i in range(0, len(myArray)):
      myArray[i] = int(myArray[i])

  return myArray

numbers = read()
size = len(numbers)  


def menu():
    print('\n1-enter 1 for array algorithm '
         ' \n2-enter 2 for linked list algorithm' 
         ' \n3-enter 3 for B-tree algorithm'
         ' \n4-enter 4 for Exit')
    
   

def writeList(): 
    writeCodeIn = open("fSortedlist.txt","w") 
    for i in range(size): 
        writeCodeIn.write(str(numbers[i])+"\n")   
    writeCodeIn.close()  
menu() 
option = int(input('Enter your choice: '))

while option != 0 :
    #check what choice was entered and act accordingly
    if option == 1: 
        arrayAlgorithm.numbers=numbers
        arrayAlgorithm.size=len(numbers)
        arrayAlgorithm.main()
        menu()            
        option = int(input('Enter your choice: ')) 
        
    elif option == 2: 
        LinkedList_Algorithm.numbers=numbers
        LinkedList_Algorithm.size=len(numbers)
        LinkedList_Algorithm.main()
        menu()            
        option = int(input('Enter your choice: ')) 
 
    
    
    if option == 3: 
        BtreeAlgorithems.numbers=numbers
        BtreeAlgorithems.size=len(numbers)
        BtreeAlgorithems.main()
        menu()            
        option = int(input('Enter your choice: '))        
     
    elif option == 4: 
      break