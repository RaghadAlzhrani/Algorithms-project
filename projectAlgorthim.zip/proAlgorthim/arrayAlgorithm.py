import random
import timeit
import time 

 



def partitionlinear(arr, low, high,q): 
   i = (low-1)         # index of smaller element   
   arr[high], arr[q] = arr[q], arr[high] 
   key = arr[high]     # pivot 
   for j in range(low, high): 
 
       # If current element is smaller than or 
       # equal to pivot 
       if arr[j] <= key: 
 
           # increment index of smaller element 
           i = i+1 
           arr[i], arr[j] = arr[j], arr[i] 
 
   arr[i+1], arr[high] = arr[high], arr[i+1] 
   return (i+1) 
     
  


def Select(arr, l, r, k): 
  
    # if k is smaller than number of 
    # elements in array 
  #  print(k) 
    if (k > 0 and k <= r - l + 1): 
  
        # Partition the array around last 
        # element and get position of pivot 
        # element in sorted array 
    #    print(l,"  ",r," ") 
        index = partitionlinear(arr, l, r, r) 
  
        # if position is same as k 
        if (index - l == k - 1): 
            return index 
  
        # If position is more, recur 
        # for left subarray 
        if (index - l > k - 1): 
            return Select(arr, l, index - 1, k) 
  
        # Else recur for right subarray 
        return Select(arr, index + 1, r, 
                            k - index + l - 1) 
    print("Index out of bound") 
   
       
    
 
def quickSelect(arr, low, high): 

    if len(arr) == 1: 
        return arr 
    if low < high: 
 
        # pi is partitioning index, arr[p] is now 
        # at right place 
        p=Select(arr,low ,high,int((high-low)/2 +1) ) 
        pi = partitionlinear(arr, low, high,p) 
        # Separately sort elements before 
        # partition and after partition 
       
        quickSelect(arr, low, pi-1) 
        quickSelect(arr, pi+1, high)
        
  
       
       
   #-----------------------------------------------------------------------
   
   # randomaized quick sort 
   


def quicksort(arr, start , stop):
	if(start < stop):
		pivotindex = partitionrand(arr,\
							start, stop)

		quicksort(arr , start , pivotindex-1)
		quicksort(arr, pivotindex + 1, stop)

def partitionrand(arr , start, stop):


	randpivot = random.randrange(start, stop)

	arr[start], arr[randpivot] = \
		arr[randpivot], arr[start]
	return partitionrand(arr, start, stop)

    
def partitionrand(arr,start,stop):
	pivot = start # pivot
	# a variable to memorize where the
	i = start + 1
	
	# partition in the array starts from.
	for j in range(start + 1, stop + 1):
		
		if arr[j] <= arr[pivot]:
			arr[i] , arr[j] = arr[j] , arr[i]
			i = i + 1
	arr[pivot] , arr[i - 1] =\
			arr[i - 1] , arr[pivot]
	pivot = i - 1
	return(pivot)

        # Number of elements: 10,000 

#-----------------------------------------------
#randomized finding medain 

#randomized finding medain 
  
def RandomizedFindingMidean(array):
       
   print("\nThe original array : " + str(array))

   mid = len(array) // 2
   res = (array[mid] + array[~mid]) / 2

# Printing result
   print("\nMedian of array is : " + str(res))            
   array.sort()
   print("\nThe array after sorted : " + str(array))    


 #--------------------------------------------------------------
 # linear quick sort 
  
 
def read(): 
  numberOfRandomNumbers = int(input("How many numbers"+\
                                    "should the random file hold?:"))
  with open("test.txt", "w") as w:
     for n in range(0, numberOfRandomNumbers):
         w.write(str(random.randint(0, 10000)))
         w.write(",")
     w.write(str(random.randint(0, 10000)))

  with open("test.txt", "r") as f:
      myArray = f.read().split(",")

  for i in range(0, len(myArray)):
      myArray[i] = int(myArray[i])

  return myArray





def partition(arr, low, high):
	i = (low-1)		 # index of smaller element
	pivot = arr[high]	 # pivot

	for j in range(low, high):

		# If current element is smaller than or
		# equal to pivot
		if arr[j] <= pivot:

			# increment index of smaller element
			i = i+1
			arr[i], arr[j] = arr[j], arr[i]

	arr[i+1], arr[high] = arr[high], arr[i+1]
	return (i+1)

# The main function that implements QuickSort
# arr[] --> Array to be sorted,
# low --> Starting index,
# high --> Ending index

# Function to do Quick sort


def quickSort1(arr, low, high):
	if len(arr) == 1:
		return arr
	if low < high:

		# pi is partitioning index, arr[p] is now
		# at right place
		pi = partition(arr, low, high)

		# Separately sort elements before
		# partition and after partition
		quickSort1(arr, low, pi-1)
		quickSort1(arr, pi+1, high)

#----------------------------------------------------------------
def kthSmallest(arr,K):
    
    # Sort the given array
    arr.sort()
 
    # Return k'th element in the
    # sorted array
    return arr[K-1]

def kthMedian(arr,M):
    
    # Sort the given array
    arr.sort()
 
    # Return k'th element in the
    # sorted array
    return arr[M-1]   
     
  #--------------------------------------------------------------------------

def menu2():
    print('\n1-enter 1 for linear median finding algorithm'
          '\n4-enter 2 for linear quick sort algorithm'
          '\n3-enter 3 for randomized median finding algorithm'
         ' \n2-enter 4 for randomized quick sort algorithm' 
         ' \n5-enter 5 for order statistics')

numbers=[]
size=0
def main():
    menu2() 
    option2 = int(input('Enter your choice: '))
    
    if option2 == 1:
        st = timeit.timeit()
        quickSelect(numbers,0,size-1)
        et = timeit.timeit()
        extime = et-st
        print("the run time is ", extime)
        mid = len(numbers) // 2
        res = (numbers[mid] + numbers[~mid]) / 2
        print("\nMedian of array is : " + str(res)) 
        print (numbers)
        
    elif option2 == 2: 
        st = timeit.timeit()
        quickSort1(numbers,0,size-1)
        et = timeit.timeit()
        extime = et-st
        print("the run time is ", extime)
        print (numbers)        
       
             
    elif option2 == 3: 
      st = timeit.timeit()
      RandomizedFindingMidean(numbers)
      et = timeit.timeit()
      extime = et-st
      print("the run time is ", extime)
      RandomizedFindingMidean(numbers)
      print (numbers)       
        
        
    elif option2 == 4:
       st = timeit.timeit()
       quicksort(numbers,0,size-1)
       et = timeit.timeit()
       extime = et-st
       print("the run time is ", extime)
       print (numbers)
        
     
    elif option2 == 5:   
     M= M=int(size//2 +1)
     print('1-median\n'+ '2- rank element\n' )
    option1= int(input("choose what you want to appear ☻"))
    if option1==1:
          st = timeit.timeit()
          et = timeit.timeit()
          extime = et-st
          print("the run time is ", extime)
          print("K'th median element is",kthMedian(numbers, M))
    elif option1==2:
           st = timeit.timeit()
           et = timeit.timeit()
           extime = et-st
           print("the run time is ", extime)
           K= int(input("index element"))
           print("K'th RANK element is",kthSmallest(numbers, K))
          
          
    print (numbers) 
       
    menu2() 
    option2 = int(input('Enter your choice: '))




