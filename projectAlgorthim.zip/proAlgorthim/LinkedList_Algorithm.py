#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb  3 19:32:27 2023

@author: shathaal-harbi
"""
'''
sort a linked list using quick sort

'''
import random
import time

def read(): 
  numberOfRandomNumbers = int(input("\nHow many numbers should the random file hold?:"))
  with open("test.txt", "w") as w:
     for n in range(0, numberOfRandomNumbers):
         w.write(str(random.randint(0, 10000)))
         w.write(",")
     w.write(str(random.randint(0, 10000)))

  with open("test.txt", "r") as f:
      myArray = f.read().split(",")

  for i in range(0, len(myArray)):
      myArray[i] = int(myArray[i])

  return myArray

#--------------------------------------------------------------
# linear quick sort 

    
class Node:
	  def __init__(self, val):
		  self.data = val
		  self.next = None


class QuickSortLinkedList:

	  def __init__(self):
		  self.head = None

	  def addNode(self, data):
		  if (self.head == None):
		      self.head = Node(data)
		  return

		  curr = self.head
		  while (curr.next != None):
			  curr = curr.next

		  newNode = Node(data)
		  curr.next = newNode

	  def printList(self, n):
		  while (n != None):
			  print(n.data, end=" ")
			  n = n.next

	  ''' takes first and last node,but do not
	   break any links in the whole linked list'''

	  def partitionLast(self, start, end):
		  if (start == end or start == None or end == None):
			  return start

		  pivot_prev = start
		  curr = start
		  pivot = end.data

		  '''iterate till one before the end,
		  no need to iterate till the end because end is pivot'''

		  while (start != end):
			  if (start.data < pivot):

				# keep tracks of last modified item
				  pivot_prev = curr
				  temp = curr.data
				  curr.data = start.data
				  start.data = temp
				  curr = curr.next
			  start = start.next

		  '''swap the position of curr i.e.
		  next suitable index and pivot'''

		  temp = curr.data
		  curr.data = pivot
		  end.data = temp

		  ''' return one previous to current because
		current is now pointing to pivot '''
		  return pivot_prev

	  def sort(self, start, end):
		  if(start == None or start == end or start == end.next):
			  return

		# split list and partition recurse
		  pivot_prev = self.partitionLast(start, end)
		  self.sort(start, pivot_prev)

		  '''
		if pivot is picked and moved to the start,
		that means start and pivot is same
		so pick from next of pivot
		'''
		  if(pivot_prev != None and pivot_prev == start):
			  self.sort(pivot_prev.next, end)

		# if pivot is in between of the list,start from next of pivot,
		# since we have pivot_prev, so we move two nodes
		  elif (pivot_prev != None and pivot_prev.next != None):
			  self.sort(pivot_prev.next.next, end)

    
    
#----------------------------------------------------------------
# order static 


# Node class 

 # Constructor to create a new node 
class Node:
      def __init__(self, val):
          self.data = val
          self.next = None

# Linked List class contains a Node object 
class LinkedList_: 

 # Function to initialize head 
   def __init__(self): 
    self.head = None

 # This function is in LinkedList class. It inserts a new node at the beginning of Linked List. 
   def push(self, new_data): 

  # 1 & 2: Allocate the Node & Put in the data 
    new_node = Node(new_data) 

  # 3. Make next of new Node as head 
    new_node.next = self.head 

        # 4. Move the head to point to new Node   
    self.head = new_node  

    # This function returns K'th smallest element from a given linked list
    
   def kth_smallest(self,k): 
      current = self.head 
      count = 0 
  
      while (current != None): 
          if (count == k): 
              return current.data 
          count += 1
          current = current.next  
 
      return 0
 
    
# Driver program to test above functions and create linked list with user input values   

#-----------------------------------------------
#linear finding medain 

class Node:
    def __init__(self, val):
        self.data = val
        self.next = None
  
  
class QuickSortLinkedList_:
  
    def __init__(self):
        self.head = None
  
    def addNode(self, data):
        if ( self.head == None):
            self.head = Node(data)
            return
  
        curr = self.head
        while (curr.next != None):
            curr = curr.next
  
        newNode = Node(data)
        curr.next = newNode
  
    def printList(self, n,file):
        while (n != None): 
            print(n.data)
            file.write(str(n.data)+"\n")
            n = n.next
  


    def partitionLast(self, start, end):
        if (start == end or start == None or end == None):
            return start
  
        pivot_prev = start
        curr = start
        pivot = end.data
  
        '''iterate till one before the end, 
        no need to iterate till the end because end is pivot'''
  
        while (start != end):
            if (start.data < pivot):
                # keep tracks of last modified item
                pivot_prev = curr
                temp = curr.data
                curr.data = start.data
                start.data = temp
                curr = curr.next
            start = start.next
  
        '''swap the position of curr i.e. 
        next suitable index and pivot'''
  
        temp = curr.data
        curr.data = pivot
        end.data = temp
  
        ''' return one previous to current because 
        current is now pointing to pivot '''
        return pivot_prev
  
    def sort(self, start, end):
        if(start == None or start == end or start == end.next):
            return
  
        # split list and partition recurse
        pivot_prev = self.partitionLast(start, end)
        self.sort(start, pivot_prev)
  
        '''
        if pivot is picked and moved to the start,
        that means start and pivot is same 
        so pick from next of pivot
        '''
        if(pivot_prev != None and pivot_prev == start):
            self.sort(pivot_prev.next, end)
  
        # if pivot is in between of the list,start from next of pivot,
        # since we have pivot_prev, so we move two nodes
        elif (pivot_prev != None and pivot_prev.next != None):
            self.sort(pivot_prev.next.next, end)
          

    
#-----------------------------------------------
#randomized finding medain 

class Node:
     
    def __init__(self, value):
         
        self.data = value
        self.next = None
     
class LinkedListt:
 
    def __init__(self):
         
        self.head = None
 
    # Create Node and make linked list
    def push(self, new_data):
         
        new_node = Node(new_data)
        new_node.next = self.head
        self.head = new_node
         
    # Function to get the median
    # of the linked list   
    def median(self): 

       temp = self.head  

       count = 0
       while (temp): 
           count += 1
           temp = temp.next

       temp = self.head  

       if (count % 2 == 0): 

           mid1, mid2, i = 0, 0, 0

           while (temp and i < count // 2 + 1): 
               mid1, mid2, i = mid2, temp.data, i + 1
               temp = temp.next

           return float((mid1 + mid2) / 2) 

       else: 

           mid, i = 0, 0

           while (temp and i < count // 2 + 1): 
               mid, i = temp.data, i + 1
               temp = temp.next

           return float(mid)

 
#--------------------------------------------------------------------------
arr=read()
def menu3():    
    print('\n1-enter 1 for linear quick sort algorithm'
          '\n2-enter 2 for order statistics'
          '\n3-enter 3 for linear median finding algorithm'
         ' \n4-enter 4 for randomized median finding algorithm'
         ' \n5-enter 5 for Exit')

def main():
 while True: 
    menu3() 
  
    option3 = int(input('Enter your choice: '))
    
    #-----------------------------------------------
    #linear quick sort algorithm
    if option3 == 1:
        
        start = time.process_time()

        ll_ = QuickSortLinkedList()
        for x in arr:
           ll_.addNode(x) 
        N = ll_.head
        while (N.next != None):
           N = N.next
        N = ll_.head
        while (N.next != None):
       	 N = N.next   
        ll_.sort(ll_.head, N)    
         
        print('\nTime linear quick sort algorithm in linked list :',time.process_time()-start)
        
    	
    #-----------------------------------------------
    #order statistics 
    elif option3 == 2: 
        
       start = time.process_time()
          
       llist = LinkedList_() # Create a linked list object and assign it to llist variable   
       for i in range(0,len(arr)):   # Iterate over range 0 - nums and append each element into linked list    
           arr.sort()
           llist.push(arr[i])    
       k=int(input("\nEnter Kth smallest element you want:"))  # Ask user for input elements and append it into linked list using push() method  
       N= len(arr)
       M=int(N//2 +1)
       rank=(N-k)
       print("\nK'th rank element is",llist.kth_smallest(rank))    
       print("K'th median element is",llist.kth_smallest(M) )
       
       print('\nTime kth in linked list :', time.process_time()-start)
      
       
    #-----------------------------------------------
    #linear median finding algorithm            
    elif option3 == 3: 
        
        start = time.process_time()
          
        ll = QuickSortLinkedList_()  
        for x in arr:
           ll.addNode(x)   
        N2 = ll.head
        while (N2.next != None):
               N2 = N2.next
        ll.sort(ll.head, N2)
        print("\nLinked List after sorting")
        print(Node)
        writeCodeIn = open("Linkedlist.txt","w") 
        ll.printList(ll.head,writeCodeIn)
        writeCodeIn.close()
        
        print('\nTime linear median finding algorithm in linked list :',time.process_time()-start)
        
        
   #-----------------------------------------------
   #randomized finding medain      
    elif option3 == 4:
        
        start = time.process_time()
          
        llist = LinkedListt()
        for x in arr:  
          arr.sort()
          llist.push(arr[x]) 
        print("\nMedian of linked list is : " + str(llist.median()))
        
        print('\nTime Randomized Finding Midean in linked list :', time.time()-start)
        
              
    elif option3 == 5: 
      break  
  
   
   
   

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    