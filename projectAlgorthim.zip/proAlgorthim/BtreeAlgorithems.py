# -*- coding: utf-8 -*-
"""
Created on Tue Feb  7 00:57:16 2023

@author: IDEAS
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Feb  6 23:18:03 2023

@author: shathaal-harbi
"""

import random
import time



def read(): 
  numberOfRandomNumbers = int(input("\nHow many numbers should the random file hold?:"))
  with open("test.txt", "w") as w:
     for n in range(0, numberOfRandomNumbers):
         w.write(str(random.randint(0, 10000)))
         w.write(",")
     w.write(str(random.randint(0, 10000)))

  with open("test.txt", "r") as f:
      myArray = f.read().split(",")

  for i in range(0, len(myArray)):
      myArray[i] = int(myArray[i])

  return myArray

#--------------------------------------------------------------
# linear quick sort 

    


# Helper function that allocates a new node with the given data and None left and right pointers.
class newNode1:

    # Constructor to create a new node
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None

def InsertTreeb(root, data): 
    if root is None: 
       return newNode1(data) 
  
    else: 
        if data <= root.data: 
            cur = InsertTreeb(root.left, data) 
            root.left = cur 
        else: 
            cur = InsertTreeb(root.right, data) 
            root.right = cur 

    return root


""" Function to count nodes in
    a binary search tree using
     Morris Inorder traversal"""


def counNodes(root):
    # Initialise count of nodes as 0
    count = 0

    if (root == None):
        return count

    current = root
    while (current != None):

        if (current.left == None):

            # Count node if its left is None
            count += 1

            # Move to its right
            current = current.right

        else:
            """ Find the inorder predecessor of current """
            pre = current.left

            while (pre.right != None and
                   pre.right != current):
                pre = pre.right

            """ Make current as right child of its
            inorder predecessor """
            if (pre.right == None):

                pre.right = current
                current = current.left
            else:

                pre.right = None

                # Increment count if the current
                # node is to be visited
                count += 1
                current = current.right

    return count

def quickSort(head): 
    if head is None or head.right is None: 
        return head 

    pivot = partition(head) 

    pivot.left = quickSort(pivot.left) 

    pivot.right = quickSort(pivot.right) 

    return pivot 

  
def partition(head): 

    pivot = head 

    prev = None

    curr = head 

    while curr is not None: 

        if curr.data < pivot.data:  

           prev = insertBeforePivot(prev, curr, pivot)  

        curr = curr.right  

    return pivot  

def insertBeforePivot(prev, curr, pivot):  

    if prev is None:  

        curr.right = pivot 

        return curr  

    else:  

        prev.right = curr.right  
        
        curr.right = pivot 
        
def printList(head): 
    temp = head 
    while temp is not None: 
        print (temp.data, end=" ")       
        temp=temp . right
        

    
#----------------------------------------------------------------
# order static 
class newNode:

    # Constructor to create a new node
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None

def InsertTree(root, data): 
    if root is None: 
       return newNode(data) 
  
    else: 
        if data <= root.data: 
            cur = InsertTreeb(root.left, data) 
            root.left = cur 
        else: 
            cur = InsertTreeb(root.right, data) 
            root.right = cur 

    return root


""" Function to count nodes in
    a binary search tree using
     Morris Inorder traversal"""


def counNode(root):
    # Initialise count of nodes as 0
    count = 0

    if (root == None):
        return count

    current = root
    while (current != None):

        if (current.left == None):

            # Count node if its left is None
            count += 1

            # Move to its right
            current = current.right

        else:
            """ Find the inorder predecessor of current """
            pre = current.left

            while (pre.right != None and
                   pre.right != current):
                pre = pre.right

            """ Make current as right child of its
            inorder predecessor """
            if (pre.right == None):

                pre.right = current
                current = current.left
            else:

                pre.right = None

                # Increment count if the current
                # node is to be visited
                count += 1
                current = current.right

    return count
def kthSmallest(root, k): 
  
    # Count to iterate  
    # over elements till we 
    # get the kth smallest  
    c = 0 
  
    # Stack to hold ancestors  
    stack = [] 
  
    # done flag 
    done = 0 

    current = root 

    while (not done): 

        if current is not None: 

            stack.append(current) 

            current = current.left 

        else: 

            if (len(stack) > 0): 

                current = stack.pop() 

                c += 1

                if (c == k): 
                    print("Kth Smallest Element is",current.data)  
                    print("Rank of the number is",c)  

                    done = 1

                current = current.right  

            else: 
                done = 1

 
def findMedian2(root):
    	if (root == None):
    		return 0
    	count = counNodes(root)
    	currCount = 0
    	current = root

    	while (current != None):
    	
    		if (current.left == None):
    		
    			# count current node
    			currCount += 1

    			# check if current node is the median
    			# Odd case
    			if (count % 2 != 0 and currCount == (count + 1)//2):
    			 return current.data

    			# Even case
    			elif (count % 2 == 0 and currCount == (count//2)+1):
    			 return (current.data + current.data)//2

    			# Update prev for even no. of nodes
    			prev = current

    			#Move to the right
    			current = current.right
    		
    		else:
    		
    			""" Find the inorder predecessor of current """
    			pre = current.left
    			while (pre.right != None and
    					pre.right != current):
    				pre = pre.right

    			""" Make current as right child of its inorder predecessor """
    			if (pre.right == None):
    			
    				pre.right = current
    				current = current.left
    			else:
    			
    				pre.right = None

    				prev = pre

    				# Count current node
    				currCount+= 1

    				# Check if the current node is the median
    				if (count % 2 != 0 and
    					currCount == (count + 1) // 2 ):
    					return current.data

    				elif (count%2 == 0 and
    					currCount == (count // 2) + 1):
    					return (prev.data+current.data)//2

    				# update prev node for the case of even
    				# no. of nodes
    				prev = current
    				current = current.right
def printList1(head): 
    temp = head 
    while temp is not None: 
        print (temp.data, end=" ")       
        temp=temp . right
        
def output():
    root = newNode(0)
    for x in numbers:
        InsertTree(root, x)  
    n = counNode(root)
    print ("what you want is : "
           "1\meadian"
           "2\element of the rank")
    optionuser=int(input("enter chocies element"))
    if optionuser==1:
        print("medain",findMedian2(root))
        printList1(root)
    if optionuser==2:   
      k=int(input("enter rank the element"))
      kthSmallest(root, k)
      printList1(root)
       
#-----------------------------------------------
#linear finding medain
def quickSort1(arr): 
    if len(arr) <= 1:
        return arr
    else: 
        pivot = findMedian(arr) 
        less = [x for x in arr if x < pivot] 
        equal = [x for x in arr if x == pivot] 
        greater = [x for x in arr if x > pivot] 

        return quickSort(less) + equal + quickSort(greater)  

    
def findMedian(arr): 
    n = len(arr) 

    # Sort the array  
    arr.sort()  

    # Return median element  
    if n % 2 != 0: 
        return arr[n//2]  

    else: 
        return (arr[n//2] + arr[n//2 - 1]) / 2
    

#-----------------------------------------------
#randomized finding medain 

MIN=-2147483648
_MAX=2147483648

# Helper function that allocates
# a new node with the given data
# and None left and right pointers.									
class newNode2:

	# Constructor to create a new node
	def __init__(self, data):
		self.data = data
		self.left = None
		self.right = None

""" A utility function to insert a new node with
given key in BST """
def insert(node,key):

	""" If the tree is empty, return a new node """
	if (node == None):
		return newNode(key)

	""" Otherwise, recur down the tree """
	if (key < node.data):
		node.left = insert(node.left, key)
	elif (key > node.data):
		node.right = insert(node.right, key)

	""" return the (unchanged) node pointer """
	return node


""" Function to count nodes in a binary search tree using Morris Inorder traversal"""
def counNodes1(root):

	# Initialise count of nodes as 0
	count = 0

	if (root == None):
		return count

	current = root
	while (current != None):
	
		if (current.left == None):
		
			# Count node if its left is None
			count+=1

			# Move to its right
			current = current.right
		
		else:	
			""" Find the inorder predecessor of current """
			pre = current.left

			while (pre.right != None and
					pre.right != current):
				pre = pre.right

			""" Make current as right child of its inorder predecessor """
			if(pre.right == None):
			
				pre.right = current
				current = current.left
			else:
			
				pre.right = None

				# Increment count if the current
				# node is to be visited
				count += 1
				current = current.right

	return count



""" Function to find median in O(n) time and O(1) space using Morris Inorder traversal"""
def findMedian1(root):
	if (root == None):
		return 0
	count = counNodes(root)
	currCount = 0
	current = root

	while (current != None):
	
		if (current.left == None):
		
			# count current node
			currCount += 1

			# check if current node is the median
			# Odd case
			if (count % 2 != 0 and currCount == (count + 1)//2):
			 return current.data

			# Even case
			elif (count % 2 == 0 and currCount == (count//2)+1):
			 return (current.data + current.data)//2

			# Update prev for even no. of nodes
			prev = current

			#Move to the right
			current = current.right
		
		else:
		
			""" Find the inorder predecessor of current """
			pre = current.left
			while (pre.right != None and
					pre.right != current):
				pre = pre.right

			""" Make current as right child of its inorder predecessor """
			if (pre.right == None):
			
				pre.right = current
				current = current.left
			else:
			
				pre.right = None

				prev = pre

				# Count current node
				currCount+= 1

				# Check if the current node is the median
				if (count % 2 != 0 and
					currCount == (count + 1) // 2 ):
					return current.data

				elif (count%2 == 0 and
					currCount == (count // 2) + 1):
					return (prev.data+current.data)//2

				# update prev node for the case of even
				# no. of nodes
				prev = current
				current = current.right

		
# Driver Code







#----------------------------------------------------------------
# quick sort algothem
def partition1(array, low, high):

	# Choose the rightmost element as pivot
	pivot = array[high]

	# Pointer for greater element
	i = low - 1

	# Traverse through all elements
	# compare each element with pivot
	for j in range(low, high):
		if array[j] <= pivot:
			# If element smaller than pivot is found
			# swap it with the greater element pointed by i
			i = i + 1

			# Swapping element at i with element at j
			(array[i], array[j]) = (array[j], array[i])

	# Swap the pivot element with
	# e greater element specified by i
	(array[i + 1], array[high]) = (array[high], array[i + 1])

	# Return the position from where partition is done
	return i + 1

# Function to perform quicksort


def quick_sort(array, low, high):
	if low < high:

		# Find pivot element such that
		# element smaller than pivot are on the left
		# element greater than pivot are on the right
		pi = partition1(array, low, high)

		# Recursive call on the left of pivot
		quick_sort(array, low, pi - 1)

		# Recursive call on the right of pivot
		quick_sort(array, pi + 1, high)


 
#--------------------------------------------------------------------------

def menu3():    
    print('\n1-enter 1 for linear quick sort algorithm'
          '\n2-enter 2 for order statistics'
          '\n3-enter 3 for linear median finding algorithm'
         ' \n4-enter 4 for randomized median finding algorithm'
         ' \n5-enter 5 for quick sort algorthem'
         ' \n6-enter 6 for exit')
         
         
numbers=[]
size=0
def main():

 while True: 
    menu3() 
    
    option3 = int(input('Enter your choice: '))
    
    #-----------------------------------------------
    #linear quick sort algorithm
    if option3 == 1:
        
        root = newNode1(0)
        for x in numbers:
          InsertTreeb(root, x)  
        n = counNodes(root)
        start=time.time()
        quickSort(root)
        print('TIME : ' ,time.time()-start) 
        printList(root)
           
         
       
        
    	
    #-----------------------------------------------
    #order statistics 
    elif option3 == 2: 
        
        start=time.time()
        output()
        print('TIME : ' ,time.time()-start) 
                
        
        
       
      
       
    #-----------------------------------------------
    #linear median finding algorithm            
    elif option3 == 3: 
        
        
        numbers.sort()
        print(numbers)
        start = time.perf_counter()
        print(time.perf_counter()-start)
        mid = len(numbers) // 2
        res = (numbers[mid] + numbers[~mid]) / 2
        print("\nMedian of array is : " + str(res)) 
        
        
   #-----------------------------------------------
   #randomized finding medain      
    elif option3 == 4:
        
        # Driver Code
        root1 = newNode2(0)
        for x in numbers:
            insert(root1, x)  
        n = counNodes(root1)
        start_time = time.perf_counter()
        print("\nMedian of BST is: ",findMedian1(root1))
        end_time = time.perf_counter()
        print('\nTime Randomized Finding Midean in linked list :',end_time - start_time)
        
          
        
        
    elif option3 == 5:
      start_time = time.time()  
      numbers.sort
      quick_sort( numbers, 0, len(numbers) - 1)
      print (numbers)
      
      
      end_time = time.time()
      print('time ',end_time-start_time)
  # This code is contributed by Adnan Aliakbar  
    elif option3 == 6: 
       break